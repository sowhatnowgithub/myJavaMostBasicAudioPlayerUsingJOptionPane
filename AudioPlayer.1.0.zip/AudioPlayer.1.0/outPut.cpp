#include<iostream>
#include<stdio.h>
int main(){
    freopen("output.txt","w",stdout);
    
    system("realpath ~/Desktop/music/*");
}