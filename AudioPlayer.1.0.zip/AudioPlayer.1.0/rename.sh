#!/bin/bash
echo "convering operation undergoing >>>>>>>>>>>>>>>>>>"

cd /users/pavan/Desktop/Music/
rename 's/ /_/g' *
